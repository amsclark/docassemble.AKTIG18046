$(document).on('daPageLoad', function(){
  document.querySelectorAll('.container')[1].classList.add('container-fluid');
  document.querySelectorAll('.container')[1].classList.remove('container');
});