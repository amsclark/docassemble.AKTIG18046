$(document).on('daPageLoad', function(){
  document.querySelector("#hslNav").remove();
});

