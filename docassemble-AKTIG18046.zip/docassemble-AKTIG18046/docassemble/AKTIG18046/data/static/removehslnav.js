$(document).on('daPageLoad', function(){
  document.getElementsByClassName("hslNavContainer")[0].remove();
  document.getElementById("hslNav").style.borderBottom = "none";
});

