$(document).on('daPageLoad', function(){
var danavbar = document.querySelectorAll('[role="navigation"]');
panicButton = document.createElement("a");
panictext = document.createTextNode("Emergency Exit to Google");
panicButton.appendChild(panictext);
panicButton.setAttribute("href", "https://www.google.com");
panicButton.setAttribute("class", "btn btn-danger");
danavbar[0].appendChild(panicButton);
});