$(document).on('daPageLoad', function(){
  var sidebar = document.querySelector("#dabody > div.container-fluid > div:nth-child(2) > div > div")
  panicButton = document.createElement("a");
  panictext = document.createTextNode("Emergency Exit to Google");
  panicButton.appendChild(panictext);
  panicButton.setAttribute("href", "https://www.google.com");
  panicButton.setAttribute("class", "btn btn-danger");
  sidebar.appendChild(panicButton);
});