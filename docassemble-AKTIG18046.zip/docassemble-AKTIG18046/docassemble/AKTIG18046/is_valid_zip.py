def is_valid_zip(zip):
  chunks = zip.split('-')
  valid = False
  if len(chunks) == 2: 
    if len(chunks[0]) == 5 and len(chunks[1]) == 4:
      valid = True
  if len(chunks) == 1:
    if len(chunks[0]) == 5:
      valid = True
  return valid