def is_valid_ssn(ssn):
  chunks = ssn.split('-')
  valid = False
  if len(chunks) == 3: 
   if len(chunks[0]) == 3 and len(chunks[1]) == 2 and len(chunks[2]) == 4:
       valid = True
  if ssn == '':
    valid = True
  return valid
