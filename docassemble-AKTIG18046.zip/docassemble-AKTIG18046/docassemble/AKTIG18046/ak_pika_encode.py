menu_asset_type = {
"No Assets": "7",
"Personal Property": "1",
"Real Property": "2",
"Checking": "3",
"Savings": "4",
"Automobile": "5",
"Other": "9",
"Group": "G"
}
reversed_menu_asset_type = dict(map(reversed, menu_asset_type.items()))

menu_gender = {
"Female": "F",
"Male": "M",
"Other": "O"
}
reversed_menu_gender = dict(map(reversed, menu_gender.items()))

menu_c4a_gender = {
"Male": "M",
"Female": "F",
"Transgender Female to Male": "TFM",
"Transgender Male to Female": "TMF",
"Genderqueer/Gender Non-binary": "GNB",
"Not listed, please specify": "NL",
"Declined/not stated": "D"
}
reversed_menu_c4a_gender = dict(map(reversed, menu_c4a_gender.items()))


menu_citizen = {
"Citizen": "A",
"Eligible Alien": "B",
"DV/Trafiking exception": "F",
"Verbal - brief only/no in-person contact": "E",
"Undocumented Alien": "C"
}
reversed_menu_citizen = dict(map(reversed, menu_citizen.items()))

menu_disability = {
"Chronic Alcohol/Drug Addiction (trust)": "A1",
"Developmental (trust)": "A10",
"Mental (trust)": "A11",
"Alzheimer's/Dementia (trust)": "A26",
"TBI (trust)": "A29",
"Digestive": "A20",
"Genito-urinary": "A21",
"Lymphatic": "A22",
"Skin": "A23",
"Endocrine": "A24",
"Cancer": "A25",
"Multiple Disabilities": "A27",
"Respiratory": "A19",
"Speech": "A18",
"Geriatric": "A12",
"Musculoskeletal": "A13",
"Cardiovascular": "A14",
"Neurological": "A16",
"Sensory": "A17",
"Other (specify in notes)": "A28"
}
reversed_menu_disability = dict(map(reversed, menu_disability.items()))

menu_dom_viol = {
"No": "0",
"Yes - Abuse to Female": "1",
"Yes - Abuse to Male": "2",
"Yes (Don't Use)": "3"
}
reversed_menu_dom_viol = dict(map(reversed, menu_dom_viol.items()))

menu_ethnicity = {
"White, non-Hispanic": "W",
"African American": "B",
"Hispanic": "H",
"Alaska Native or Native American": "N",
"Asian": "A",
"Pacific Islander": "P",
"Multiple ethnicities": "M"
}
reversed_menu_ethnicity = dict(map(reversed, menu_ethnicity.items()))

menu_income_freq = {
"Annual": "A",
"Monthly": "M",
"Bi-Weekly": "B",
"Weekly": "W"
}
reversed_menu_income_freq = dict(map(reversed, menu_income_freq.items()))

menu_expenses_freq = {
"Annual": "A",
"Monthly": "M",
"Bi-Weekly": "B",
"Weekly": "W"
}
reversed_menu_expenses_freq = dict(map(reversed, menu_expenses_freq.items()))

menu_expenses = {
"Rent/Mortgage": "S",
"Child Care/Support": "X",
"Medical": "W",
"Other": "Z"
}
reversed_menu_expenses = dict(map(reversed, menu_expenses.items()))



menu_income_type = {
"Employment": "A",
"ATAP (Alaska Temporary Assistance Program) or TANF (Temporary Assistance for Needy Families)": "D",
"Adult Public Assistance": "L",
"Veterans Benefits": "P",
"Interim Assistance": "O",
"Wages/Earnings": "A",
"Alimony/Child Support": "G",
"Retirement/Pension": "F",
"Social Security": "B",
"SSI (Supplemental Security Income)": "C",
"Unemployment": "E",
"Worker's Comp": "K",
"Other": "Z"
}
reversed_menu_income_type = dict(map(reversed, menu_income_type.items()))

menu_intake_type = {
"Active Intake": "B1",
"Email": "A6",
"Walk-in Without Appointment": "A3",
"Fax Intake": "A4",
"Other": "H1",
"Off-Site Intake": "F1",
"Village Travel": "E1",
"DV Shelter": "D1",
"Senior Outreach": "C1",
"Emergency": "B2",
"Telephone": "A1",
"Mail": "A5",
"Walk-in By Appointment": "A2",
"Phone Hotline": "G1",
"AMHCW Outreach": "J1"
}
reversed_menu_intake_type = dict(map(reversed, menu_intake_type.items()))

menu_just_income = {
"High cost of living in rural AK": "E",
"Obtain Govmt. Benefits low inc/disabled": "A",
"High unreimb. medical expenses": "B",
"High fixed debt -rent/mortgage": "F",
"High Fixed debt -other": "N",
"Child care/employment expenses": "I",
"Income prospects/seasonal variation": "J",
"Age/disability expense (not med)": "K",
"Current taxes": "L",
"Other factors  - see notes": "G",
"MAINTAIN Gov. Benefit low inc": "M",
"ED Waiver on file": "H",
"Over Income Funding code used": "D",
"DO NOT USE No Affordable Altern. - see notes": "C"
}
reversed_menu_just_income = dict(map(reversed, menu_just_income.items()))

menu_language = {
"English": "1",
"Spanish": "7",
"Yupik": "2",
"Athabascan": "4",
"Inupiat": "3",
"Other Alaska Native": "5",
"Tagalog": "14",
"Hmong": "36",
"American Sign": "6",
"Russian": "11",
"African Languages": "45",
"Arabic": "43",
"Armenian": "27",
"Cambodian": "10",
"Chinese": "12",
"French": "8",
"French Creole": "17",
"German": "13",
"Greek": "23",
"Gujarati": "29",
"Hebrew": "44",
"Hindi": "30",
"Hungarian": "42",
"Italian": "18",
"Japanese": "34",
"Korean": "9",
"Laotian": "16",
"Mon-Khmer, Cambodian": "35",
"Navajo": "41",
"Persian": "28",
"Polish": "24",
"Portuguese": "19",
"Serbo-Croatian": "25",
"Scandinavian Languages": "22",
"Thai": "37",
"Ukranian": "15",
"Urdu": "31",
"Vietnamese": "38",
"Yiddish": "20",
"Other Asian lang.": "39",
"Other Indic langs.": "32",
"Other Indo-European lang.": "33",
"Other Pacific Island Lang": "40",
"Other Slavic langs.": "26",
"Other West Germanic lang.": "21",
"Other Languages": "97",
"Not Specified": "0"
}
reversed_menu_language = dict(map(reversed, menu_language.items()))

menu_lsc_income_change = {
"Not Likely to Change": "0",
"Likely to Increase": "1",
"Likely to Decrease": "2"
}
reversed_menu_lsc_income_change = dict(map(reversed, menu_lsc_income_change.items()))

menu_marital = {
"Single": "1",
"Married": "2",
"Divorced": "3",
"Separated": "4",
"Widowed": "5",
"Domestic Partner": "7"
}
reversed_menu_marital = dict(map(reversed, menu_marital.items()))

menu_office = {
"Anchorage": "AN",
"Barrow": "BA",
"Bethel": "BE",
"Dillingham": "DI",
"Fairbanks": "FA",
"Juneau": "JU",
"Kenai": "KN",
"Ketchikan": "KE",
"Kodiak": "KD",
"Kotzebue": "KO",
"MLP": "MLP",
"Native Law": "NL",
"Online Intake": "OI",
"Nome": "NO",
"Palmer": "PA",
"Pro Bono": "PB",
"Statewide": "SW",
"Dillingham(2)": "DL",
"Pro Bono Estates": "PB2",
"Fairbanks2": "FI",
"Wall Cases": "WL"
}
reversed_menu_office = dict(map(reversed, menu_office.items()))

menu_referred_by = {
"Internet": "I",
"Family": "E",
"Friend": "F",
"Prior Use": "P",
"Court": "C",
"Community Organization": "D",
"Private Bar": "B",
"Outreach": "G",
"Other LS Program": "L",
"GA > SSI via DHS": "Q",
"Social Agency": "S",
"Telephone Book": "T",
"Other": "0",
"Unknown": "U",
"Adult Farm Mgmt.": "Y",
"Farm Advocate": "Z",
"Advertisement": "A"
}
reversed_menu_referred_by = dict(map(reversed, menu_referred_by.items()))

menu_referral = {
"(no referral)": "",
"Alaska Lawyer Referral": "1",
"Alaska Pro Bono Program, Inc.": "2",
"Alaska Civil Liberties Union": "3",
"AK Ct. System  Family Law Self-Help Center": "4",
"Adult Protective Services": "5",
"Alaska Human Rights Commission": "7",
"AlaskaLawHelp": "8",
"Alaska Permanent Fund": "9",
"Alaska State Ombudsman": "11",
"Division of Public Assistance -SC/NW": "13",
"Office of Victim's Rights": "14",
"Healthy Alaskans Info Line": "15",
"Older Alaskans Ombudsman": "17",
"Out of State Legal Services Program": "18",
"Social Security Administration - Anchorage": "19",
"Access Alaska - Anchorage": "A001",
"Adult Public Assistance": "A003",
"Advocates for Victims of Violence": "A005",
"Alaska AIDS Assistance Association": "A007",
"Alaska Alliance for the Mentally Ill": "A009",
"Alaska CARES": "A010",
"Alaska Court System - Anchorage": "A011",
"Alaska Court System - Homer": "A013",
"Alaska Court System - Kenai": "A015",
"Alaska Court System - Palmer": "A017",
"Alaska Court System - Unalaska": "A019",
"Alaska Child Abuse Prevention Network": "A020",
"Alaska Court System - Valdez": "A021",
"Alaska Landlord Tenant Services": "A023",
"Alaska Native Justice Center": "A025",
"Alaska Public Defender Agency - Anchorage": "A027",
"Alaska Public Defender Agency - Kenai": "A029",
"Alaska Public Defender Agency - Palmer": "A031",
"Alaska Public Utilities Commission": "A033",
"Alaska Women's Resource Center (AWRC)": "A035",
"American Red Cross": "A037",
"American Red Cross - Counseling": "A039",
"Anchorage Center for Families": "A041",
"Anchorage Neighborhood Health & Dental": "A043",
"Anchorage Neighborhood Housing": "A045",
"Anchorage Police Department": "A046",
"Anchorage Rescue Mission": "A047",
"Anchorage Senior Center": "A049",
"ARC of Anchorage": "A051",
"Abused Women's Aid in Crisis (AWAIC)": "A053",
"AYPF Runaway Shelter": "A055",
"Beans Cafe and Day Shelter": "A057",
"Beyond Shelter - Catholic Social Services": "A059",
"Brother Francis Shelter": "A061",
"Catholic Social Services": "A063",
"Center for the Blind": "A065",
"Center for the Deaf": "A067",
"Chugiak Senior Center": "A069",
"Circle of Care": "A071",
"Clare House": "A073",
"Community Advocacy Project": "A075",
"Consumer Credit Counseling Service (Anch)": "A076",
"Cook Inlet Tribal Council": "A077",
"Cordova Family Resource Center (CFRC)": "A079",
"Cornerstone Clinic - Christian Health Assoc.": "A081",
"Covenant House": "A083",
"Daycare Assistance Program": "A085",
"Disability Law Center - Anchorage": "A087",
"Div. of Family & Youth Svcs - Anch.": "A089",
"Division of Public Assistance - Anchorage": "A091",
"Intermission": "A093",
"Kenai/Soldotna Women's Resource Center": "A095",
"Laurel Shelter": "A097",
"Lutheran Social Services & Native Outreach": "A099",
"Mabel T. Caverly Senior Center": "A101",
"Male Awareness Program": "A103",
"McKinnell Shelter": "A105",
"Mental Health Consumers of Alaska": "A107",
"Mountain View Health Clinic": "A109",
"Native Outreach": "A111",
"Office of Public Advocacy - Anchorage": "A113",
"Older Alaskans Transportation Services": "A115",
"Older Persons Action Group (OPAG)": "A117",
"Palmer Senior Center": "A119",
"Salvation Army Older Alaskans Program": "A121",
"Seward Life Action Council (SLAC)": "A123",
"South Peninsula Women's Services (SPWS)": "A125",
"Southcentral Counseling": "A127",
"Southcentral Foundation": "A129",
"Standing Together Against Rape (STAR)": "A131",
"Unalaskans Against Sexual Assault": "A133",
"Valley Women's Resource Center (VWRC)": "A135",
"Veteran's Administration": "A137",
"Veteran's Center/Resource (Anchorage)": "A139",
"Veterans Outreach Center": "A141",
"Veterans Transitional Housing": "A143",
"Wasilla Area Seniors": "A145",
"Women/Infant/Children (WIC) Program": "A149",
"Alaska Court System - Barrow": "B001",
"Alaska Public Defender Agency - Barrow": "B003",
"Arctic Slope Native Association": "B005",
"Arctic Slope Regional Corporation": "B007",
"Arctic Women in Crisis (AWIC)": "B009",
"Counseling Services": "B011",
"Division of Family & Youth Services - Barrow": "B013",
"Native Village of Barrow": "B015",
"Ukpeagvik Inupiat Corporation": "B017",
"Alaska Court System - Bethel": "C001",
"Alaska Public Defender Agency - Bethel": "C003",
"Alaska State Troopers - Bethel": "C005",
"Association of Village Council Presidents": "C007",
"Bethel Fire Department": "C009",
"Bethel Police Department": "C011",
"Division of Public Assistance - Bethel": "C013",
"Disability Law Center of Alaska - Bethel": "C015",
"District Attorney's Office - Bethel": "C017",
"Division of Family & Youth Services - Bethel": "C019",
"Emmonak Women's Shelter (EWS)": "C021",
"Law Office of Chris Cooke": "C023",
"Tundra Women's Coalition": "C025",
"Alaska Court System - Dillingham": "D001",
"Alaska Public Defender Agency - Dillingham": "D003",
"Alaska State Troopers - Dillingham": "D005",
"Alaska State Troopers - King Salmon": "D007",
"Bristol Bay Housing Authority": "D009",
"Bristol Bay Native Association": "D011",
"District Attorney - Dillingham": "D013",
"Division of Family & Youth Services - Dill.": "D015",
"Senior Citizens Center - Dillingham": "D017",
"Safe and Fear Free Environment (SAFE)": "D019",
"Ketchikan Senior Center": "K011",
"PATH (Park Ave. Transitional Housing)": "K012",
"Social Security Administration - Ketchikan": "K013",
"Southeast Senior Services -- Ketchikan": "K014",
"Women in Safe Homes (WISH)": "K015",
"Alaska Court System - Kodiak": "L001",
"Alaska Public Defender Agency - Kodiak": "L003",
"Kodiak Senior Center": "L005",
"Kodiak Women's Resource and Crisis Center": "L007",
"AHFC Public Housing Division - Nome": "N001",
"Alaska Court System - Kotzebue": "N003",
"District Attorney -- Ketchikan": "K010",
"Division of Public Assistance - Ketchikan": "K009",
"Office of Public Advocacy - Juneau": "J046",
"Family Resource Center - Juneau": "J047",
"SAFE Child Advocacy Center": "J048",
"Housing First": "J049",
"Juneau Youth Services": "J050",
"Love, Inc.": "J052",
"AHFC - Ketchikan": "K001",
"Alaska Court System - Ketchikan": "K003",
"Alaska Public Defender Agency - Ketchikan": "K005",
"Alaska State Troopers -- Prince of Wales": "K006",
"Division of Family & Youth Services-Ketchikan": "K007",
"Alaska Court System - Nome": "N005",
"Alaska Public Defender Agency - Kotzebue": "N007",
"Alaska Public Defender Agency - Nome": "N009",
"XYZ Senior Center - Nome": "N037",
"AHFC - Sitka": "O001",
"Alaska Court System - Sitka": "O003",
"Alaska Public Defender Agency - Sitka": "O005",
"Division of Family & Youth Services - Sitka": "O007",
"District Attorney -- Sitka": "O008",
"Sitkans Against Family Violence (SAFV)": "O009",
"Sitka Family Justice Center": "O010",
"Sitka Tribal Association": "O011",
"Pro Se Clinic": "P1",
"Social Security Administration-Int./Northern": "N035",
"Quyanna Care Center": "N033",
"Norton Sound Health Corporation": "N031",
"Alaska State Troopers - Nome": "N011",
"Bering Sea Women's Group (BSWG)": "N013",
"Bering Straits Regional Housing Authority": "N015",
"Child Care Assistance Program - Nome": "N017",
"Division of Family & Youth Services - Nome": "N019",
"Division of Public Assistance - Nome": "N021",
"Kawerak, Inc.": "N023",
"Maniilaq Family Crisis Center (MFCC)": "N025",
"Nome Food Bank": "N027",
"Northern Lights Recovery Center - Nome": "N029",
"(other agency)": "ZZZZ",
"Access Alaska - Fairbanks": "F001",
"Family Focus - Fairbanks": "F027",
"Interior Neighborhood Health Clinic": "F029",
"Legal Learning Lab": "F030",
"Salvation Army - Fairbanks": "F031",
"Interior Alaska Center for Non-Violent Living": "F035",
"AHFC Public Housing Division - Juneau": "J001",
"Aiding Women in Abuse & Rape Emergencies": "J003",
"Alaska Court System - Juneau": "J005",
"Alaska Network on DV and Sexual Assault": "J007",
"Alaska Public Defender Agency - Juneau": "J009",
"Fairbanks Resource Agency - Senior Svcs.": "F025",
"Fairbanks Rescue Mission": "F023",
"Fairbanks Regional Public Health Center": "F021",
"Alaska Court System - Fairbanks": "F003",
"Alaska Public Defender - Fairbanks": "F005",
"Child Support Enforcement Div. - Fairbanks": "F007",
"Consumer Credit Counseling Service (Fbx)": "F008",
"Deaf Community Services": "F009",
"Disability Law Center - Fairbanks": "F011",
"Division of Family & Youth Services - Fbx.": "F013",
"Division of Motor Vehicles - Fairbanks": "F015",
"Division of Public Assistance - Fairbanks": "F017",
"DV Protective Order Office - Fairbanks": "F019",
"Big Brothers/Big Sisters of Juneau": "J011",
"Catholic Community Services Family Resources": "J013",
"Child Support Services Division -- Juneau": "J014",
"Social Security Administration - Juneau": "J033",
"Southeast Alaska Health Consortium": "J035",
"Southeast Senior Services -- Juneau": "J036",
"St. Vincent de Paul": "J037",
"Valley Senior Center - Juneau": "J039",
"Gateway Human Services": "J040",
"Glory Hole": "J041",
"Helping Hands": "J042",
"SERRC (Southeast Regional Resource Center)": "J043",
"Shanti": "J044",
"Salvation Army - Juneau": "J031",
"SAIL (SE Alaska Independent Living)": "J030",
"REACH, Inc.": "J029",
"Central Council - Tlingit & Haida": "J015",
"Consumer Credit Counseling Service (Juneau)": "J016",
"Disability Law Center - Juneau": "J017",
"District Attorney's Office -- Juneau": "J018",
"Division of Family & Youth Services - Juneau": "J019",
"Division of Public Assistance - Juneau": "J021",
"Eldercare Management - Juneau": "J023",
"Gastineau Human Services": "J024",
"Juneau Alliance for the Mentally Ill": "J025",
"Juneau Mental Health Center": "J027",
"Southeast Alaska Food Bank": "J045"
}
reversed_menu_referral = dict(map(reversed, menu_referral.items()))

menu_referral_lom = {
"121 - Referred to other provider of civil legal services": "121",
"122 - Referred to private bar": "122",
"123 - Referred to provider of human or social services": "123",
"129 - Referred to other source of  assistance": "129"
}
reversed_menu_referral_lom = dict(map(reversed, menu_referral_lom.items()))

menu_residence = {
"Apartment": "A",
"Rented Home": "B",
"Condominium": "C",
"House": "H",
"Institutionalized": "I",
"Jail": "J",
"Nursing Home": "N",
"Assisted Living": "O",
"Prison": "P",
"Mobile Home": "T",
"Relatives": "X",
"Shelter": "Y",
"Homeless": "Z",
"Boat": "S",
"Other": "D"
}
reversed_menu_residence = dict(map(reversed, menu_residence.items()))

menu_yesno = {
True: "Yes",
False: "No",
"1": "Yes",
"0": "No",
"": "No"
}