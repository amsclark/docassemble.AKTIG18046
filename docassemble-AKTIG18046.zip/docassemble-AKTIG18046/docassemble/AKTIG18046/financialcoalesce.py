from docassemble.base.util import defined 

def coalesce_employment(financialslist):
  monthlytotal = 0
  idx = 0
  for financialitem in financialslist:
    monthlytotal += financialitem.wage * financialitem.hours * 52 / 12
    idx = idx + 1
  return monthlytotal

def coalesce_other(financialslist):
  monthlytotal = 0
  idx = 0
  for financialitem in financialslist:
    monthlytotal += financialitem.amt
    idx = idx + 1
  return monthlytotal


def coalesce(financialslist):
  monthlytotal = 0
  idx = 0
  for financialitem in financialslist:
    if defined('financialitem.amt'):
      monthlytotal += financialitem.amt * monthisize_factor(financialitem)
    else:
      monthlytotal += financialitem.wage * financialitem.hours * 52 / 12
    idx = idx + 1
  return monthlytotal

def monthisize_factor(monthisize_item):
    if defined('monthisize_item.frequency'):
      if monthisize_item.frequency == "M":
        return 1
      elif monthisize_item.frequency == "A":
        return 1 / 12
      elif monthisize_item.frequency == "W":
        return 52 / 12
      elif monthisize_item.frequency == "B":
        return 26 / 12
      else:
        return 1
    else:
      return 1
      
def add_amt_attr_and_sort(nonstandard_items_list):      
  for nonstandard_item in nonstandard_items_list:
    if not defined('nonstandard_item.amt'):
      if  defined('nonstandard_item.wage') and defined('nonstandard_item.hours'):
        nonstandard_item.amt = nonstandard_item.wage * nonstandard_item.hours * 52 / 12
    else:
      nonstandard_item.amt = nonstandard_item.amt * monthisize_factor(nonstandard_item.amt)
  standard_items_list = nonstandard_items_list.sort_elements(key=lambda item: item.amt, reverse=True)
  return standard_items_list
      
      